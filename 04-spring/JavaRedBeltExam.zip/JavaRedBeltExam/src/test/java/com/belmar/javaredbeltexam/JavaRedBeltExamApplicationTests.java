package com.belmar.javaredbeltexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaRedBeltExamApplicationTests {

	@Test
	void contextLoads() {
	}

}
